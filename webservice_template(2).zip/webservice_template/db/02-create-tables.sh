sqlite3 authors.db < ddl.sql
