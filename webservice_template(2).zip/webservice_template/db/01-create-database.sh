sqlite3 authors.db
