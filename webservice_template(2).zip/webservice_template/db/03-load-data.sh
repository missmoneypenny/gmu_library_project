sqlite3 authors.db < data.sql
