package edu.gmu.authorservice.dao;

import edu.gmu.authorservice.model.Author;

import java.util.Collection;

public class InMemoryAuthorDao implements AuthorDao {

    @Override
    public Author getAuthor(Integer id) {
        return null;  // TODO - implement me!
    }

    @Override
    public Collection<Author> getAllAuthors() {
        return null;  // TODO - implement me!
    }
}
